import React from 'react'

export default function Tab () {
  return (
    <div>Tab</div>
  )
}
