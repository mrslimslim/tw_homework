import React from 'react'

export default function PageLoading () {
  return (
    <div>
            PageLoading
    </div>
  )
}
