import React from 'react'

export default function Footer () {
  return (
    <div className='tw_footer'>© Copyright 2019 ThoughtWorks</div>
  )
}
