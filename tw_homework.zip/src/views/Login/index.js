import React from 'react'

const Login = () => {
  return (
    <div>
            Login page
    </div>
  )
}

export default Login
