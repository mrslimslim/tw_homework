import React, { Component } from 'react'

export default class HelpPage extends Component {
  render () {
    return (
      <div>
        HelpPage
      </div>
    )
  }
}
