import React, { Component } from 'react'

export default class DashboardPage extends Component {
  render () {
    return (
      <div>DashboardPage</div>
    )
  }
}
