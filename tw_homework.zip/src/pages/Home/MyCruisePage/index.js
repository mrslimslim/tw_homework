import React, { Component } from 'react'

export default class MycruisePage extends Component {
  render () {
    return (
      <div>
        MycruisePage
      </div>
    )
  }
}
